#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define pi 3.141592653589793

int main(int argc, char *argv[]) {
    int Nx, Ny, i, j, n, nt, noutput;
    double dx, dy, dt, Tf, Lx, Ly;
    double **T, **Tnew, **temp;
    FILE *fp;

    if (argc != 2) {
        printf("Usage: %s inputfile\n", argv[0]);
        return 1;
    }

    fp = fopen(argv[1], "r");
    if (!fp) {
        printf("Unable to open input file %s\n", argv[1]);
        return 1;
    }

    // ? Fixed input parsing
    fscanf(fp, "%lf %lf", &Lx, &Ly);
    fscanf(fp, "%d %d", &Nx, &Ny);
    fscanf(fp, "%lf", &Tf);
    fscanf(fp, "%d", &noutput);
    fclose(fp);

    // ? Debug output
    printf("Read inputs: Lx=%.3f Ly=%.3f Nx=%d Ny=%d Tf=%.6f noutput=%d\n", Lx, Ly, Nx, Ny, Tf, noutput);

    dx = Lx / (Nx - 1);
    dy = Ly / (Ny - 1);
    dt = 0.25 * dx * dx;  // Stability condition for explicit method

    nt = (int)(Tf / dt);
    printf("dx = %f, dy = %f, dt = %e, nt = %d\n", dx, dy, dt, nt);

    // Memory allocation
    T = (double **)malloc(Nx * sizeof(double *));
    Tnew = (double **)malloc(Nx * sizeof(double *));
    for (i = 0; i < Nx; i++) {
        T[i] = (double *)malloc(Ny * sizeof(double));
        Tnew[i] = (double *)malloc(Ny * sizeof(double));
    }

    // Initial condition: T = sin(pi x) * sin(pi y)
    for (i = 0; i < Nx; i++) {
        for (j = 0; j < Ny; j++) {
            double x = i * dx;
            double y = j * dy;
            T[i][j] = sin(pi * x) * sin(pi * y);
        }
    }

    // Time stepping loop
    for (n = 0; n <= nt; n++) {
        for (i = 1; i < Nx - 1; i++) {
            for (j = 1; j < Ny - 1; j++) {
                Tnew[i][j] = T[i][j] + dt * (
                    (T[i + 1][j] - 2 * T[i][j] + T[i - 1][j]) / (dx * dx) +
                    (T[i][j + 1] - 2 * T[i][j] + T[i][j - 1]) / (dy * dy)
                );
            }
        }

        // Boundary conditions: T = 0 on all boundaries
        for (i = 0; i < Nx; i++) {
            Tnew[i][0] = Tnew[i][Ny - 1] = 0.0;
        }
        for (j = 0; j < Ny; j++) {
            Tnew[0][j] = Tnew[Nx - 1][j] = 0.0;
        }

        // Swap T and Tnew
        temp = T;
        T = Tnew;
        Tnew = temp;

        // Output temperature field at intervals
        if (n % noutput == 0) {
            char filename[256];
            sprintf(filename, "T_x_y_%06d.dat", n);
            FILE *fout = fopen(filename, "w");
            for (i = 0; i < Nx; i++) {
                for (j = 0; j < Ny; j++) {
                    fprintf(fout, "%f %f %f\n", i * dx, j * dy, T[i][j]);
                }
            }
            fclose(fout);
            printf("Output written to %s\n", filename);
        }
    }

    // Free memory
    for (i = 0; i < Nx; i++) {
        free(T[i]);
        free(Tnew[i]);
    }
    free(T);
    free(Tnew);

    return 0;
}
