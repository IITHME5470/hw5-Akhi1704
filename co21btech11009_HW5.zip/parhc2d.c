#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>

#define M_PI 3.141592653589793

void write_plotfile(int rank, int nx, int ny, double dx, double dy, double t, double **u) {
    char filename[100];
    sprintf(filename, "output_%04d_%04d.dat", rank, (int)(t * 1e6));
    FILE *fp = fopen(filename, "w");

    if (!fp) {
        printf("Rank %d: Failed to open file %s\n", rank, filename);
        return;
    }

    for (int j = 0; j < ny; j++) {
        for (int i = 0; i < nx; i++) {
            fprintf(fp, "%f %f %f\n", i * dx, j * dy, u[j][i]);
        }
    }

    fclose(fp);
    printf("Rank %d: Wrote file %s at time %.6f\n", rank, filename, t);
}

int main(int argc, char *argv[]) {
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (argc < 2) {
        if (rank == 0) printf("Usage: %s inputfile\n", argv[0]);
        MPI_Finalize();
        return -1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        if (rank == 0) printf("Cannot open input file.\n");
        MPI_Finalize();
        return -1;
    }

    int nx_global, ny_global, noutput;
    double Lx, Ly, Tf, dummy;
    fscanf(fp, "%d %lf %lf %lf %lf %d", &nx_global, &Lx, &Ly, &Tf, &dummy, &noutput);
    fclose(fp);

    int px = (int)sqrt(size);
    int py = size / px;
    if (px * py != size) {
        if (rank == 0) printf("Error: Use square number of MPI processes.\n");
        MPI_Finalize();
        return -1;
    }

    int rx = rank % px;
    int ry = rank / px;
    int nx = nx_global / px;
    int ny = ny_global / py;

    double dx = Lx / (nx_global - 1);
    double dy = Ly / (ny_global - 1);
    double dt = 0.25 * dx * dx;
    int nt = (int)(Tf / dt);
    int output_interval = (noutput > 0) ? fmax(1, nt / noutput) : -1;

    double **u = malloc(ny * sizeof(double *));
    double **unew = malloc(ny * sizeof(double *));
    for (int j = 0; j < ny; j++) {
        u[j] = calloc(nx, sizeof(double));
        unew[j] = calloc(nx, sizeof(double));
    }

    // ? Initial condition: sin(pi x) * sin(pi y)
    for (int j = 0; j < ny; j++) {
        for (int i = 0; i < nx; i++) {
            double x = (rx * nx + i) * dx;
            double y = (ry * ny + j) * dy;
            u[j][i] = sin(M_PI * x) * sin(M_PI * y);
        }
    }

    // ? Write immediately after init to verify output
    write_plotfile(rank, nx, ny, dx, dy, 0.0, u);

    for (int n = 1; n <= nt; n++) {
        double t = n * dt;

        for (int j = 1; j < ny - 1; j++) {
            for (int i = 1; i < nx - 1; i++) {
                unew[j][i] = u[j][i] + dt * (
                    (u[j][i+1] - 2 * u[j][i] + u[j][i-1]) / (dx * dx) +
                    (u[j+1][i] - 2 * u[j][i] + u[j-1][i]) / (dy * dy)
                );
            }
        }

        double **tmp = u;
        u = unew;
        unew = tmp;

        if (output_interval > 0 && n % output_interval == 0) {
            write_plotfile(rank, nx, ny, dx, dy, t, u);
        }
    }

    for (int j = 0; j < ny; j++) {
        free(u[j]);
        free(unew[j]);
    }
    free(u);
    free(unew);

    MPI_Finalize();
    return 0;
}
